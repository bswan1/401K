 /**
* @version		0.0.1 16.05.2011 $
* @package		POP-UP jQuery
* @copyright	Copyright (C) 2011 - 2012 Open Source Matters. All rights reserved.
* @license		GNU/GPL
* project page  http://www.cleverscript.ru
* support       support@cleverscript.ru
* author        cleverscript
*/
function PopUp(objj,trigg){
	var html = objj.html();
	objj.remove();
	var body = $('body')[0];
				
	var HTML="<div id='popup'><span id='cancel'></span>"+html+"</div>";
	var win = $('<div id="win">'+HTML+'</div>');
	win.appendTo(body);
	
	function showWin(){
		$('#win').css({display: 'block'});
		$('#popup').css({
			display:'block', 
			opacity:0, 
			top: $(window).height()/2-$('#popup').height()/2+'px', 
			left: $(window).width()/2-$('#popup').width()/2+'px'
		});
		$('#popup').css('opacity', 1);			
	}
		
	if($(trigg)){
		$(trigg).click(function(){
			showWin();
		});
	}
		
	if($('#cancel')){
		$('#cancel').click(function(){
			$('#win').css('display', 'none');
		});
	}
	
}

//END POP UP
$(document).ready(function(){
	$('#original_percent').on('keyup',function(){
		$('.original_percent:eq(0)').text($('#original_percent').val());
	});
    $('.original_percent').text($('#original_percent').val());
    $('#current_age').val($('#current_age').data('value'));
    
	/*$('.knob').each(function(index, value){
		var id = $(this).attr('id').replace('_knob', '')
    	, value = $(this).val()
    	, sym = $('#'+id).data('symbol');
    	$('#'+id+'_value').find('span').html(value);
    	if (sym=='$') {
    		$('#'+id).val(sym + parseInt(value));
    	} else if (sym=='%'){
    		$('#'+id).val(parseInt(value)+sym);
    	} 
	});
	*/
	$( "#tabs" ).tabs();
	Cufon.replace(".cufon");
	$('#age_of_retirment').on('change blur',function(){
		if(parseInt($('#age_of_retirment').val())<parseInt($('#current_age').val())){
			$('#age_of_retirment').val(parseInt($('#current_age').val()) + 1);
			//calculate();
		}
		
	});
            $(".header .knob").knob({
                change : function (value) {
                 	var id = this.$.attr('id').replace('_knob', '')
                 	, max= this.$.data('max')
                 	, min= this.$.data('min');
                 	if (value >= min && value <= max) {
                 		$('#'+id+'_value span').html(value);
				    	$('#'+id).val(value).change();
				    	//calculate();
				    };
                },

            });
            $(".center_post .knob").knob({
                change : function (value) {
                 	var id = this.$.attr('id').replace('_knob', '')
                 	, max= this.$.data('max')
                 	, min= this.$.data('min');
                 	if (value >= min && value <= max) {
                 		$('#'+id+'_value span').html(value);
				    	$('#'+id).val(value).change();
				    	calculateReverse();
				    };
                },

            });
			
			$("#chart").on("plothover", function (e, pos, item) {
				$('.info_popup').remove();
				if(item){
					console.log(item);
					var value = addCommas(Math.round(item.datapoint[1]));
					if(item.seriesIndex==0) var title = 'Total Value: ';
					if(item.seriesIndex==1) var title = 'Annual Contributions: ';
				$('body').prepend('<div class="info_popup" style="display:none">Age: '+Math.round(item.datapoint[0])+'<br>'+title+'$'+value+'</div>');
				$('.info_popup').css({left:item.pageX - $('.info_popup').outerWidth(true),top:item.pageY - $('.info_popup').outerHeight(true),'background':'#fff','opacity':'0.7','z-index':1000}).fadeIn(300);
				}
		});

});
	$(document).on('keyup','input[name="sec_up"]',function(){
		$(this).parent().parent().next().next().next().find('.original_percent').text($(this).val());
		//alert($(this).parent().parent().next().next().next().html());
	});

function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

function filterNum(str) {
	re = /^\$|,/g;
	return str.replace(re, "");
	}
function calculateTiered(){
	var emp_match = new Array();
	var sum = 0;
	$('input[name="emp_match"]').each(function(index, element) {
		if((parseInt($(element).val())/100> 0) && (parseInt($(element).parent().parent().next().find('input').val())/100) > 0)
        emp_match[index] = (parseInt($(element).val())/100) * (parseInt($(element).parent().parent().next().find('input').val())/100);
    });
	//alert(emp_match);
	for(var i = 0;i<emp_match.length;i++){
		//alert(emp_match[i]*100);
		sum = sum + emp_match[i] * 100;
	}
	sum=Math.round(sum);
	$('#emp_match').val(sum+'%');
	$('#emp_match').keyup();
	ShowForm();
}
function ShowForm(){
	$('.Tiered').toggle();
	$('a.button.open').toggle();
}
numbers = new Array('Third','Fourth','Fifth','Sixth','Seventh','Eighth','Ninth','Tenth');
count_lines = 0;

function addLine(){
	var count = $('input[name="sec_up"]').length - 1;
	if(numbers[count_lines]){
		var content = '<tr><th colspan="2">'+numbers[count_lines]+' Tiered Schedule</th></tr><tr><td>Employer match: (%)</td><td><input name="emp_match" value="100%" type="text"></td></tr><tr><td>Between <span class="original_percent">'+$('input[name="sec_up"]:eq('+count+')').val()+'</span> and</td><td><input name="sec_up" value="5%" type="text"></td></tr>';
		count_lines++;
		$('tr.buttons_line').before(content);
	}
}
function calculate(show_hint){  	
	$('#legend').width(186);
	$('#legend').css('right','736px')
		var tot1=filterNum($("#current_balance").val());
		$("#current_balance").val("$"+addCommas(tot1));
		var age = parseInt($("#current_age").val());
		var ret_age = parseInt($("#age_of_retirment").val());
		var years =  ret_age - age;
		var salary = parseInt($("#salary_knob").val()/1000);
		var percent = parseInt($("#cont_percent_knob").val());
		var return_rate = parseInt($("#return_rate").val());
		var emp_max = parseInt($("#emp_max").val());
		var emp_match = parseInt($("#emp_match_knob").val());
		
		var total = parseInt(filterNum($("#current_balance").val()));
		var i=1;
		var coords = new Array();
		var coords2 = new Array();
		var sal_inc = parseInt($("#sal_inc").val());
        console.log(salary+' * '+percent+' = '+salary*percent);
        if (salary*percent*10>18000){
			 //popup.open('#objj');
			 
		  alert('Warning! The 401K limit for 2016 is $18,000. This is the maximum amount that you can invest in your 401K (not including your employer contributions). Please adjust your inputs into the calculator to take this into account.');
		}
		for (i=1;i<=years;i++)
	{
		salary = salary+salary*sal_inc*0.01;
		var max = salary*emp_max*10;
		var match = salary*percent * emp_match*0.1;
		if (match > max){
			match=max;
		}
		var add_per_year = salary*percent*10+match;
		var add = total*return_rate*0.01 + add_per_year;
		total = total + add;
		var coord = new Array(i+age, total);
		coords[i-1] = coord;
		var coord2 = new Array(i+age, add);
		coords2[i-1] = coord2;

	}
		console.log(coords);
		var tot = coords[years-1][1];

	  $( "#tot" ).html( addCommas(parseInt(tot)));
	  $( "#yrs" ).html( years);
if(show_hint){
				$('#line').prepend('<div class="info_popup" style="display:none">Age: '+ret_age+'<br>'+'Total Value '+'$'+addCommas(parseInt(tot))+'</div>');
				$('.info_popup').css({right:0,top:0,'background':'#fff','opacity':'0.7','z-index':1000}).fadeIn(300);
}
	  var all_data = [
	  { label: "Total Value", color: '#5f9600', data: coords},
	  { label: "Annual Contributions", color: '#0e76bf', data: coords2}
	  
	];

	var plot_conf = {
	 series: {
	   lines: {
	     show: true,
	     lineWidth: 4,
		 fill: true,
		 fillColor: { colors: [ { opacity: 0 }, { opacity: 0.8 } ] },
	   },
	   shadowSize: 0
	 },
	 
	 legend: {
	    container: $("#legend"),
		noColumns: 2,
		labelBoxBorderColor: 'transparent',
	 },
	 
	 yaxis: {
	    tickFormatter: function (v) { return "$"+addCommas(v); } ,
		color:'#e5e5e5',
		//tickColor:'red',
		labelWidth:70,
		labelHeight:60,
		font:{
			size: 11,
			weight: "bold",
			family: "sans-serif",
			color: "#ABABAB"
		}
		//tickSize:250000
	  },
	  xaxis:{
		color:'#e5e5e5',
		ticks:5,
		tickDecimals:0
	  },
	  grid: {
		show: true,
		color: '#c8c8c8',
		borderWidth: {top:0, right: 2, bottom: 0, left: 2},
		labelMargin:5,
		hoverable:true
		//axisMargin:20,
		//markings: [ { xaxis: { from: $('#current_age').val(), to: $('#current_age').val() }, yaxis: { from: parseInt(tot)*(-1.5), to: parseInt(tot)*1.5 }, color: "red",lineWidth: 1 }],
	  },
	  hooks:{
	  shutdown: [hellohook]
	  }
	};

	$.plot($("#chart"), all_data, plot_conf);
	  
  }
  function hellohook(plot, eventHolder) { $('.graf-img').hide(); };
  function keyUpChangeValue(input) {
		var value=parseInt(input.val())
		, id=input.attr('id').replace('_knob', '')
		, max=input.data('max')
		, step=input.data('step');

  		if (value) {
  			$('#'+id).val(value);
  		};
  }

  function floorReplace(input){
  	var id=input.attr('id')
  	, max=input.data('max')
  	, step=input.data('step')
  	, rep = /[$%_!@#\^&()\-\+=, №\\\?*\/\.;":'a-zA-Zа-яА-Я]/
  	, value=input.val().replace(rep, '')
  	, sym = input.data('symbol');

  	value = parseInt(Math.floor(value/step)*step);
  	
  	if (value >= step) {
  		$('#'+id+'_knob').val(value).change();
  		$('#'+id+'_value span').html(value);
  		if (sym == '$') {
  			$(input).val(sym+value);
  		} else if(sym == '%'){
  			$(input).val(value+sym);
  		}
  	} else if (value >= max) {
  		if (sym == '$') {
  			$(input).val(sym+max);
  		} else if(sym == '%'){
  			$(input).val(max+sym);
  		}
  		$('#'+id+'_value span').html(max);
  		$('#'+id+'_knob').val(max).change();
  	} else if (value <= step) {
  		if (sym == '$') {
  			$(input).val(sym+'0');
  		} else if(sym == '%'){
  			$(input).val('0'+sym);
  		}
  		$('#'+id+'_value span').html(0);
  		$('#'+id+'_knob').val(0).change();
  	}

  }
  function validateNum(input){
  	var value=input.val(), rep = /[_!@#\^&()\-\+=, №\\\?*\/;":'a-zA-Zа-яА-Я]/; 
    	if (rep.test(value)) { 
	        value = value.replace(rep, ''); 
	        $(input).val(value); 
    	} 
  }
  function keyUpDrow(input,e){
	  //alert(e.keyCode);
	  if((e.keyCode == 37) || (e.keyCode == 39)) return false;
  		var value=input.val()
  		, id=input.attr('id')
  		, max=input.data('max')
  		, step=input.data('step')
  		, rep = /[$%]/
  		, sym = input.data('symbol');

    	var ival = value.replace(rep, '');
  
    	if (ival >= max) {
    		ival = max;
    	}
    	if (ival>=step) {
				$('#'+id+'_knob').val(ival).change();
				$('#'+id+'_value span').html(ival);
				if (sym == '$') {
		  			$(input).val(sym+ival);
		  		} else if(sym == '%'){
		  			$(input).val(ival+sym);
		  		}
			}
	}

function calculateReverse(){
	var current_balance = parseInt(filterNum($("#current_balance").val()));
	
	$("#current_balance").val('$'+addCommas(current_balance));
	$('#legend').width(186);
	$('#legend').css('right','736px')
	var age = parseInt($("#current_age").val())
	, ret_age = parseInt($("#age_of_retirment").val())
	, years =  ret_age - age
	, total = parseInt($("#salary_knob").val()/1000)
	, percent = parseInt($("#cont_percent_knob").val())
	, return_rate = parseInt($("#return_rate").val())
	, i=1
	, coords = new Array()
	, coords2 = new Array()
	, per = 0;

	for (i=1;i<=years-1;i++)  {
	 	per = per + Math.pow(1+return_rate*0.01,i);
	}

 var red = current_balance*Math.pow(1+return_rate*0.01,years);
 var salary_tot = (total*1000+red)/per;
 var salary = salary_tot/(1+percent*0.01);
 var mon = salary/12;

	$( "#total" ).html( addCommas(parseInt(total*1000)));
	$( "#ret_age" ).html( addCommas(parseInt(ret_age)));  
	$( "#tot" ).html( addCommas(parseInt(salary)));
	$( "#mon" ).html( addCommas(parseInt(mon)));

	var j =1;

	for (j=1;j<=years;j++) {
		var add_per_year = salary_tot;
		var add = total*return_rate*0.01 + add_per_year;
		total = total + add;
		var coord = new Array(j+age, total);
		coords[j-1] = coord;
		var coord2 = new Array(j+age, add);
		coords2[j-1] = coord2;
	}

  		  var all_data = [
	  { label: "Total Value", color: '#5f9600', data: coords},
	  { label: "Annual Contributions", color: '#0e76bf', data: coords2}
	  
	];

	var plot_conf = {
	 series: {
	   lines: {
	     show: true,
	     lineWidth: 4,
		 fill: true,
		 fillColor: { colors: [ { opacity: 0 }, { opacity: 0.8 } ] },
	   },
	   shadowSize: 0
	 },
	 
	 legend: {
	    container: $("#legend"),
		noColumns: 2,
		labelBoxBorderColor: 'transparent',
	 },
	 
	 yaxis: {
	    tickFormatter: function (v) { return "$"+addCommas(v); } ,
		color:'#e5e5e5',
		//tickColor:'red',
		labelWidth:70,
		labelHeight:60,
		font:{
			size: 11,
			weight: "bold",
			family: "sans-serif",
			color: "#ABABAB"
		}
		//tickSize:250000
	  },
	  xaxis:{
		color:'#e5e5e5',
		ticks:5,
		tickDecimals:0
	  },
	  grid: {
		show: true,
		color: '#c8c8c8',
		borderWidth: {top:0, right: 2, bottom: 0, left: 2},
		labelMargin:5,
		hoverable:true
		//axisMargin:20,
		//markings: [ { xaxis: { from: $('#current_age').val(), to: $('#current_age').val() }, yaxis: { from: parseInt(tot)*(-1.5), to: parseInt(tot)*1.5 }, color: "red",lineWidth: 1 }],
	  }
	};

	
	$.plot($("#chart"), all_data, plot_conf);
          
        
}
